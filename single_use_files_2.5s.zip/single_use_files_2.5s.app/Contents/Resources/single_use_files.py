#!/usr/bin/env python3

# will only work on macOS
# currently works for chrome and safari downloads but can easily be modified for more browsers

import time
import subprocess
from helpers import newest_file, intro, size_downloads,notify, start_dialog, already_started,wrong_pause, pause_dialog, time_dialog, enter_number_dialog, help_text
import multiprocessing as mp
import rumps

#'.crdownload' is what chrome uses for the temporary file while it's being downloaded
#'.download' is what safari uses for the temporary file while it's being downloaded
# if you are using other browsers you can just add the extension they use for downloading files
def main_loop(time_del):
    newest = newest_file()
    size_folder = size_downloads()
    while True:
        checkfornew = newest_file()
        new_size_folder = size_downloads()
        time.sleep(1)
        if new_size_folder >= size_folder:      #check if the new most recent is not due to a deletion
            if not checkfornew.endswith('.crdownload') and not checkfornew.endswith('.download'):
                if checkfornew != newest :
                    time.sleep(1)
                    notify(checkfornew, time_del)
                    time.sleep(1)
        if not checkfornew.endswith('.crdownload') and not checkfornew.endswith('.download'):
            newest = checkfornew
        size_folder = new_size_folder



class MenuBar(rumps.App):

    started = 0
    time_del = 0.02

    @rumps.clicked("Help/About")
    def help_about(self, _):
        help_text()

    @rumps.clicked("Start")
    def start(self, _):
        if self.started == 0:
            start_dialog()
            self.p1 = mp.Process(target=main_loop, args=(self.time_del,))
            self.p1.start()
            self.started = 1
        else :
            already_started()

    @rumps.clicked("Pause")
    def pause(self, _):
        if self.started == 1:
            pause_dialog()
            self.started = 0
            self.p1.terminate()
            self.p1.join()
        else :
            wrong_pause()

    @rumps.clicked("Set Time")
    def set_time(self, _):
        result = time_dialog()
        if result != []:
            number = result[0][34:-1]
            if number.replace('.','',1).isdigit():
                self.time_del = round(float(number),1)*60.0
            else :
                enter_number_dialog()


    @rumps.clicked("Quit App")
    def quit_app(self, _):
        if self.started == True:
            self.p1.terminate()
            self.p1.join()
        rumps.quit_application()

intro()
if __name__ == "__main__":
    app = MenuBar("⬇️App", quit_button=None)
    app.run()
